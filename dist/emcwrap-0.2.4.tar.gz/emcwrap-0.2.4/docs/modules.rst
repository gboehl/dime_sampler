Module Documentation
====================

``emcwrap.sampler``
-------------------
.. automodule:: emcwrap.sampler
   :members:
   :undoc-members:
   :show-inheritance:

``emcwrap.moves``
-------------------
.. automodule:: emcwrap.moves
   :members:
   :undoc-members:
   :show-inheritance:

``emcwrap.tools``
-------------------
.. automodule:: emcwrap.tools
   :members:
   :undoc-members:
   :show-inheritance:

``emcwrap.plots``
------------------------
.. automodule:: emcwrap.plots
   :members:
   :undoc-members:
   :show-inheritance:

``emcwrap.stats``
------------------------
.. automodule:: emcwrap.stats
   :members:
   :undoc-members:
   :show-inheritance:

``emcwrap.dists``
------------------------
.. automodule:: emcwrap.dists
   :members:
   :undoc-members:
   :show-inheritance:
